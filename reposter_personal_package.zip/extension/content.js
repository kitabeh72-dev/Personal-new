(async function(){
  const params = new URLSearchParams(location.search);
  const listingId = params.get("listing");
  if (!listingId) return;

  const { dashboardUrl } = await chrome.storage.sync.get('dashboardUrl');
  if (!dashboardUrl) { console.warn("Set dashboard URL in extension options."); return; }

  try {
    const res = await fetch(`${dashboardUrl}/api/listing?id=${listingId}`);
    if (!res.ok) throw new Error("Listing fetch failed");
    const data = await res.json();
    console.log("Filling listing", data);

    // Helper to set value and dispatch events
    const typeAndChange = (el, value) => {
      if (!el) return;
      el.focus();
      el.value = value;
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
    };

    // NOTE: Selectors are generic; you may need to adjust if LBC changes form.
    // Title
    typeAndChange(document.querySelector('input[name*="title"], input[aria-label*="titre" i]'), data.title || "");

    // Price
    if (data.price != null) {
      typeAndChange(document.querySelector('input[name*="price"], input[aria-label*="prix" i]'), String(data.price));
    }

    // Description
    typeAndChange(document.querySelector('textarea, div[contenteditable="true"]'), data.description || "");

    // City / postal code (type postal then city if available)
    if (data.postalCode) {
      const postal = document.querySelector('input[aria-label*="code postal" i], input[name*="postal" i]');
      typeAndChange(postal, data.postalCode);
      await new Promise(r => setTimeout(r, 800));
      // Select from autosuggest if exists
      const opt = document.querySelector('[role="option"], li[role="option"]');
      if (opt) opt.click();
    }

    // Category (best effort: look for a select)
    if (data.category) {
      const cat = document.querySelector('select[name*="category" i]');
      if (cat) {
        cat.value = cat.querySelector(`option[label*="${data.category}" i], option[value*="${data.category}" i]`)?.value || cat.value;
        cat.dispatchEvent(new Event('change', { bubbles: true }));
      }
    }

    // Images: open file picker not possible automatically without user gesture.
    // Instead, we display a toast to remind you to upload images.
    const note = document.createElement('div');
    note.textContent = "Autofill complete. Upload images and click Publish.";
    note.style.cssText = "position:fixed;top:10px;right:10px;padding:8px 12px;background:#111;color:#fff;border-radius:8px;z-index:999999;";
    document.body.appendChild(note);
    setTimeout(()=>note.remove(), 5000);
  } catch (e) {
    console.warn("Autofill error", e);
  }
})();
