// Reserved for future features (update checks, context menu).
chrome.runtime.onInstalled.addListener(() => {
  console.log("LBC Autofill installed");
});
