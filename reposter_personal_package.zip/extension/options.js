document.getElementById('save').onclick = async () => {
  const url = document.getElementById('url').value.trim();
  await chrome.storage.sync.set({ dashboardUrl: url });
  document.getElementById('msg').textContent = "Saved.";
};
(async () => {
  const { dashboardUrl } = await chrome.storage.sync.get('dashboardUrl');
  if (dashboardUrl) document.getElementById('url').value = dashboardUrl;
})();
