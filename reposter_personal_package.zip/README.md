# Reposter Personal Package (Dashboard + Autofill Extension)

Folders:
- `dashboard/` — Render-ready app (upload to GitHub + deploy via render.yaml)
- `extension/` — Chrome/Firefox extension (load unpacked)

See `dashboard/README.md` for setup steps.
