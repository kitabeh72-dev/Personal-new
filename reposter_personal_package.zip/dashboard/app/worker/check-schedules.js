import { Pool } from "pg";
import dayjs from "dayjs";
import { sendEmail } from "../lib/email.js";

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const main = async () => {
  const { rows } = await pool.query(
    "select * from listings where scheduled_at is not null and scheduled_at <= now() and status='scheduled' order by scheduled_at asc limit 20"
  );

  for (const r of rows) {
    const html = `
      <p>Your listing is scheduled now:</p>
      <p><strong>${r.title}</strong> (${r.location || ""} ${r.postal_code || ""})</p>
      <p><a href="https://www.leboncoin.fr/ai?listing=${r.id}" target="_blank">Open Leboncoin (auto-fill)</a></p>
      <p>Copy description if needed:</p>
      <pre>${(r.description || "").replace(/</g, "&lt;")}</pre>
    `;

    await sendEmail({
      to: process.env.ADMIN_EMAIL,
      from: process.env.EMAIL_FROM,
      subject: `It's time to post: ${r.title}`,
      html
    });

    await pool.query("update listings set status='reminded' where id=$1", [r.id]);
    await pool.query("insert into events(kind, listing_id, meta) values('reminder_sent',$1,$2)", [r.id, { emailed: true }]);
  }
};

main().then(() => process.exit(0)).catch(err => { console.error(err); process.exit(1); });
