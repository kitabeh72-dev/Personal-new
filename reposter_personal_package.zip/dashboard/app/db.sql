create table if not exists listings (
  id serial primary key,
  title text not null,
  price integer,
  category text,
  location text,
  postal_code text,
  images text[],
  description text,
  status text default 'draft',
  scheduled_at timestamptz,
  created_at timestamptz default now()
);
create table if not exists events (
  id serial primary key,
  kind text not null,
  listing_id integer references listings(id) on delete cascade,
  at timestamptz default now(),
  meta jsonb default '{}'::jsonb
);
