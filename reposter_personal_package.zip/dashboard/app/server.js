import express from "express";
import session from "cookie-session";
import { Pool } from "pg";
import dayjs from "dayjs";

const app = express();
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

app.use(express.urlencoded({ extended: true }));
app.use(express.static("public"));
app.use(session({ name: "s", secret: process.env.ADMIN_PASSWORD || "secret", maxAge: 7*24*3600*1000 }));

const layout = (title, body) => `
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${title}</title>
<link rel="stylesheet" href="https://unpkg.com/mvp.css" />
<style>
  textarea { white-space: pre-wrap; }
  .muted { opacity:.8; font-size:.9em; }
  .chip { display:inline-block; padding:.2rem .5rem; border-radius:.75rem; background:#eee; margin-right:.25rem; }
</style>
</head><body>
<header><h1>Personal LBC Scheduler</h1><nav>
  <a href="/">Dashboard</a>
  <a href="/new">New Listing</a>
  <a href="/settings">Extension</a>
  <a href="/logout">Logout</a>
</nav></header>
<main>${body}</main>
<footer><small>Personal use only • ${new Date().getFullYear()}</small></footer>
</body></html>`;

const requireAuth = (req, res, next) => {
  if (req.session?.authed) return next();
  return res.redirect("/login");
};

app.get("/login", (req, res) => {
  res.send(layout("Login", `
    <form method="post" action="/login">
      <label>Email <input type="email" name="email" required></label>
      <label>Password <input type="password" name="password" required></label>
      <button>Sign in</button>
    </form>`));
});

app.post("/login", (req, res) => {
  const { email, password } = req.body;
  if (email === process.env.ADMIN_EMAIL && password === process.env.ADMIN_PASSWORD) {
    req.session.authed = true;
    return res.redirect("/");
  }
  res.status(401).send(layout("Login failed", `<p>Wrong email or password.</p><p><a href="/login">Try again</a></p>`));
});

app.get("/logout", (req, res) => { req.session = null; res.redirect("/login"); });

app.get("/", requireAuth, async (_req, res) => {
  const { rows } = await pool.query("select * from listings order by created_at desc");
  const rowsHtml = rows.map(r => `
    <tr>
      <td><a href="/listing/${r.id}">${r.title}</a></td>
      <td>${r.price ?? ""}</td>
      <td>${r.category ?? ""}</td>
      <td>${r.location ?? ""}</td>
      <td>${r.postal_code ?? ""}</td>
      <td>${r.scheduled_at ? dayjs(r.scheduled_at).format("YYYY-MM-DD HH:mm") : "-"}</td>
      <td><span class="chip">${r.status}</span></td>
    </tr>`).join("");
  res.send(layout("Dashboard", `
    <p>Create drafts, set a schedule, and get a reminder at the right time. The extension will open the form and fill it for you.</p>
    <table>
      <thead><tr><th>Title</th><th>Price</th><th>Category</th><th>City</th><th>CP</th><th>Scheduled</th><th>Status</th></tr></thead>
      <tbody>${rowsHtml || "<tr><td colspan=7>No listings yet.</td></tr>"}</tbody>
    </table>`));
});

app.get("/new", requireAuth, (_req, res) => {
  res.send(layout("New Listing", `
    <form method="post" action="/new">
      <label>Title <input name="title" required></label>
      <label>Price (€) <input name="price" type="number"></label>
      <label>Category <input name="category" placeholder="e.g. Electronique > Téléphones"></label>
      <label>City <input name="location" placeholder="Paris"></label>
      <label>Postal code <input name="postal_code" placeholder="75011"></label>
      <label>Images (URLs, comma separated) <input name="images"></label>
      <label>Description <textarea name="description" rows="6"></textarea></label>
      <label>Schedule time (YYYY-MM-DD HH:mm) <input name="scheduled_at" placeholder="2025-08-12 20:00"></label>
      <button>Save</button>
    </form>`));
});

app.post("/new", requireAuth, async (req, res) => {
  const { title, price, category, location, postal_code, images, description, scheduled_at } = req.body;
  const imgArr = (images || "").split(",").map(s => s.trim()).filter(Boolean);
  await pool.query(
    "insert into listings(title, price, category, location, postal_code, images, description, status, scheduled_at) values($1,$2,$3,$4,$5,$6,'scheduled',$7)",
    [title, price || null, category || null, location || null, postal_code || null, imgArr, description || "", scheduled_at || null]
  );
  res.redirect("/");
});

app.get("/listing/:id", requireAuth, async (req, res) => {
  const { rows } = await pool.query("select * from listings where id=$1", [req.params.id]);
  const r = rows[0];
  if (!r) return res.status(404).send(layout("Not found", "<p>Listing not found.</p>"));

  const payload = {
    title: r.title,
    price: r.price,
    category: r.category,
    city: r.location,
    postalCode: r.postal_code,
    images: r.images || [],
    description: r.description
  };

  res.send(layout(r.title, `
    <article>
      <h2>${r.title}</h2>
      <p><strong>Price:</strong> ${r.price ?? "-"}</p>
      <p><strong>Category:</strong> ${r.category ?? "-"}</p>
      <p><strong>City:</strong> ${r.location ?? "-"}</p>
      <p><strong>Postal:</strong> ${r.postal_code ?? "-"}</p>
      <p><strong>Images:</strong> ${(r.images||[]).join(", ") || "-"}</p>
      <p><strong>Scheduled:</strong> ${r.scheduled_at ? dayjs(r.scheduled_at).format("YYYY-MM-DD HH:mm") : "-"}</p>
      <details><summary>Content</summary><pre>${payload.title}\n${payload.price?payload.price+' €':''}\n${payload.category||''}\n${payload.city||''} ${payload.postalCode||''}\n\n${payload.description}</pre></details>
      <p>
        <a href="https://www.leboncoin.fr/ai" target="_blank" rel="noopener" class="button">Open Leboncoin</a>
        <button id="copyBtn">Copy to clipboard</button>
      </p>
      <script>
        document.getElementById('copyBtn').onclick = () => {
          navigator.clipboard.writeText(${json.dumps(payload["description"])!r}).then(()=>alert('Copied!'));
        };
      </script>
      <p class="muted">Your browser extension will auto-fill when the Leboncoin form loads.</p>
    </article>`));
});

// Simple API for the extension to fetch a listing by ID (?id=)
app.get("/api/listing", async (req, res) => {
  // For personal use: no auth, but obscure URL + extension API key in headers recommended.
  const id = Number(req.query.id);
  if (!id) return res.status(400).json({ error: "id required" });
  const { rows } = await pool.query("select * from listings where id=$1", [id]);
  const r = rows[0];
  if (!r) return res.status(404).json({ error: "not found" });
  res.json({
    id: r.id,
    title: r.title,
    price: r.price,
    category: r.category,
    city: r.location,
    postalCode: r.postal_code,
    images: r.images || [],
    description: r.description
  });
});

app.get("/settings", requireAuth, (_req, res) => {
  res.send(layout("Extension Setup", `
    <h2>Extension Setup</h2>
    <ol>
      <li>Load the extension in Chrome (Developer Mode → Load unpacked).</li>
      <li>Open the extension Options page.</li>
      <li>Set your Dashboard URL (this site) and a Listing ID to test.</li>
    </ol>
    <p class="muted">When you open a Leboncoin "Créer une annonce" page with <code>?listing=ID</code> in the URL, the extension fetches the draft and fills it.</p>
  `));
});

app.get("/api/health", (_req, res) => res.json({ ok: true }));

const ensureDb = async () => {
  await pool.query("select 1");
  await pool.query(`create table if not exists listings (id serial primary key, title text not null, price integer, category text, location text, postal_code text, images text[], description text, status text default 'draft', scheduled_at timestamptz, created_at timestamptz default now());`);
  await pool.query(`create table if not exists events (id serial primary key, kind text not null, listing_id integer references listings(id) on delete cascade, at timestamptz default now(), meta jsonb default '{}'::jsonb);`);
};

ensureDb().then(() => {
  const port = process.env.PORT || 10000;
  app.listen(port, () => console.log("Personal LBC app on :" + port));
});
