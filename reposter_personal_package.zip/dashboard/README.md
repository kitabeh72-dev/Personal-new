# Personal LBC Scheduler + Autofill Extension (Option A)

This package contains:
- **dashboard/** (Render-ready server) — manage drafts and schedules.
- **extension/** — Chrome/Firefox extension that auto-fills Leboncoin's "create ad" form using your draft.

## Quick Deploy (Render + GitHub)
1. Create a new GitHub repo and upload `dashboard/` contents and `render.yaml` at the repo root.
2. In Render: New → Blueprint → select your repo → Deploy.
3. Set environment variables on the web service:
   - `ADMIN_EMAIL`, `ADMIN_PASSWORD`
   - `EMAIL_FROM`, `RESEND_API_KEY`
4. Open your site → log in → create a listing. Note its **ID** from the URL.

## Extension Install
1. Go to Chrome → `chrome://extensions/` → enable Developer Mode.
2. Click **Load unpacked**, select the `extension/` folder.
3. Click **Details → Extension options** and set:
   - Dashboard URL (e.g., `https://yourapp.onrender.com`).
4. To test: open `https://www.leboncoin.fr/ai?listing=LISTING_ID` — the extension fetches and fills.

## Notes
- If Leboncoin changes the form, you may need an updated extension. Reloading takes ~20s.
- This is for **personal use**; no third-party account automation beyond local autofill.
